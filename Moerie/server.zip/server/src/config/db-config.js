const DB_CONFIG = {
    host: 'localhost',
    user: 'root',
    password: 'new_password',
    database: 'sys',
  };
  
  module.exports = DB_CONFIG;